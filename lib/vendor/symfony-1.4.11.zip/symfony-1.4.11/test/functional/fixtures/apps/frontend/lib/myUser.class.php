<?php

class myUser extends sfBasicSecurityUser
{
}
