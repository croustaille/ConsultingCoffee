<div class="partial">OK</div>
