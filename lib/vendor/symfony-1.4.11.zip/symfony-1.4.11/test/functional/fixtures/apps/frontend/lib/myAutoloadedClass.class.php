<?php

class myAutoloadedClass
{
  public function getFoo()
  {
    return 'foo';
  }
}
